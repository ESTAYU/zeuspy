PollType
========

.. autoclass:: zeuspy.enums.PollType()
    :members:

.. raw:: html
    :file: ./cleanup.html