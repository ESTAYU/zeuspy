NextCodeType
============

.. autoclass:: zeuspy.enums.NextCodeType()
    :members:

.. raw:: html
    :file: ./cleanup.html