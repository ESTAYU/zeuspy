MessagesFilter
==============

.. autoclass:: zeuspy.enums.MessagesFilter()
    :members:

.. raw:: html
    :file: ./cleanup.html