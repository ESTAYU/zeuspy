SentCodeType
============

.. autoclass:: zeuspy.enums.SentCodeType()
    :members:

.. raw:: html
    :file: ./cleanup.html