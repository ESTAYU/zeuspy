ChatType
========

.. autoclass:: zeuspy.enums.ChatType()
    :members:

.. raw:: html
    :file: ./cleanup.html