UserStatus
==========

.. autoclass:: zeuspy.enums.UserStatus()
    :members:

.. raw:: html
    :file: ./cleanup.html