ChatMemberStatus
================

.. autoclass:: zeuspy.enums.ChatMemberStatus()
    :members:

.. raw:: html
    :file: ./cleanup.html