MessageMediaType
================

.. autoclass:: zeuspy.enums.MessageMediaType()
    :members:

.. raw:: html
    :file: ./cleanup.html