MessageEntityType
=================

.. autoclass:: zeuspy.enums.MessageEntityType()
    :members:

.. raw:: html
    :file: ./cleanup.html