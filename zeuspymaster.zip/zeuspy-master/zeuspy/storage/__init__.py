#ZEUS- I START FROM THRE, WHERE EVERYONE GIVE-UP

from .file_storage import FileStorage
from .memory_storage import MemoryStorage
from .storage import Storage
