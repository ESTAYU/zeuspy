#ZEUS- I START FROM THRE, WHERE EVERYONE GIVE-UP

from .input_message_content import InputMessageContent
from .input_text_message_content import InputTextMessageContent

__all__ = [
    "InputMessageContent", "InputTextMessageContent"
]
